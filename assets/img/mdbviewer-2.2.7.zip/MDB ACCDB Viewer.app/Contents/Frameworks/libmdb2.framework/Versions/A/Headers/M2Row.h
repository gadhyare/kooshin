//
//  M2Row.h
//  libmdb2
//
//  Created by Jakob Egger on 29.01.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class M2Table;
@interface M2Row : NSArray {
	M2Table *table;
	uint32_t recordId;
}

@property(readonly) M2Table *table;

-(id)initWithTable:(M2Table*)aTable recordId:(uint32_t)aRecordId;
-(id)objectAtIndex:(NSUInteger)index error:(NSError**)outError;
-(id)objectAtIndex:(NSUInteger)index rowData:(NSData*)rowData flags:(uint16_t)flags error:(NSError**)outError;

-(NSArray*)allObjects;

/**
 * Get the row as a dictionary
 */
-(NSDictionary*)dictionaryWithError:(NSError**)outError;

-(id)objectForKey:(id)aKey error:(NSError**)outError;
@end
