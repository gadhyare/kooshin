//
//  M2Table.h
//  libmdb2
//
//  Created by Jakob Egger on 23.01.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class M2Database, M2PageMap, M2Row;

@interface M2Table : NSObject {
	/**
	 * General variables
	 */
	M2Database *mdb;
	NSString *name;
	NSArray *columns;
	NSDictionary *indexForColumnName;
	
	NSArray *indices;
	
	/**
	 * Data from MSysObjects
	 */
	NSDictionary *metadata;
	
	/**
	 * Properties from the TDEF page
	 */
	uint32_t tdefPageIndex;
	uint32_t tdefLength;
	uint32_t unknownA;
	uint32_t numRows;
	uint32_t autonumber;
	uint32_t autonumberIncrement; // possibly the increment?
	uint32_t complexAutonumber;
	uint32_t unknownB;
	uint32_t unknownC;
	uint8_t tableType;
	uint16_t nextColumnId;
	uint16_t numColsVariable;
	uint16_t numCols;
	uint32_t numIndices;
	uint32_t numIndicesReal;
	
	M2PageMap *pagemap, *pagemapFree;
	
}
@property(readonly) M2Database *mdb;
@property(copy) NSString *name;
@property(copy) NSDictionary *metadata;
@property(readonly) NSArray *columns;
@property(readonly) NSArray *indices;
@property(readonly) NSDictionary *indexForColumnName;
@property(readonly) M2PageMap *pagemap, *pagemapFree;

@property(readonly) uint32_t numRows;



-(id)initWithDatabase:(M2Database*)aDatabase;
-(BOOL)readTableDefinitionFromPage:(uint32_t)pageIndex error:(NSError**)outError;

-(M2Row*)rowWithId:(uint32_t)rowId;
-(uint32_t)nextRowIdAfter:(uint32_t)rowId includeDeleted:(BOOL)includeDeleted error:(NSError**)outError;


@end
