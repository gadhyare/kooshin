//
//  M2Column.h
//  libmdb2
//
//  Created by Jakob Egger on 24.01.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    M2ColumnTypeBool = 0x01,
    M2ColumnTypeInt8 = 0x02,
    M2ColumnTypeInt16 = 0x03,
    M2ColumnTypeInt32 = 0x04,
    M2ColumnTypeDecimal64 = 0x05,
    M2ColumnTypeFloat32  = 0x06,
    M2ColumnTypeFloat64 = 0x07,
    M2ColumnTypeDatetime = 0x08,
    M2ColumnTypeBinary = 0x09,
    M2ColumnTypeText = 0x0A,
    M2ColumnTypeOle = 0x0B,
    M2ColumnTypeMemo = 0x0C,
    M2ColumnTypeGuid = 0x0F,
    M2ColumnTypeDecimal96 = 0x10,
	M2ColumnTypeComplex = 0x12
} M2ColumnType;

#define M2ColumnTypeIsFractional(x) ((x)==M2ColumnTypeFloat32||(x)==M2ColumnTypeFloat64||(x)==M2ColumnTypeDecimal64||(x)==M2ColumnTypeDecimal96)
#define M2ColumnTypeIsInteger(x) ((x)==M2ColumnTypeInt8||(x)==M2ColumnTypeInt16||(x)==M2ColumnTypeInt32||(x)==M2ColumnTypeComplex)
#define M2ColumnTypeIsNumeric(x) (M2ColumnTypeIsInteger(x)||M2ColumnTypeIsFractional(x))
#define M2ColumnTypeIsTextual(x) ((x)==M2ColumnTypeMemo||(x)==M2ColumnTypeText)

typedef enum {
    M2ColumnFlagFixedLength = 0x0001,
	M2ColumnFlagNull = 0x0002,
	M2ColumnFlagAutonumber = 0x0004,
	M2ColumnFlag08 = 0x0008,
	M2ColumnFlagReplication = 0x0010,
	M2ColumnFlag20 = 0x0020,
	M2ColumnFlagAutoguid = 0x0040,
	M2ColumnFlagHyperlink = 0x0080,
	M2ColumnFlagUnicodeCompressed = 0x0100,
	M2ColumnFlagOleAttachment2007 = 0x1000
} M2ColumnFlag;

@class M2Table, M2ObjectReader;

@interface M2Column : NSObject {
	M2Table *table;
	NSString *name;	
	
	uint8_t type;
	uint16_t flags;
	uint8_t digitsTotal, digitsFraction;
	uint16_t locale, codepage, complexTypeDefinitionPage;
	
	uint16_t columnId, columnIndex;
	uint16_t fixedColumnOffset, variableColumnIndex, length;
	
	uint32_t unknownA, unknownB, unknownC;	
	uint32_t arg1, arg2;
	
	
	NSStringEncoding stringEncoding;
	
	M2ObjectReader *objectReader;
}
@property(assign) M2Table *table;
@property(copy) NSString *name;
@property(readonly) uint16_t flags, columnId, columnIndex, fixedColumnOffset, variableColumnIndex, length;
@property(readonly) uint32_t arg1, arg2;
@property(readonly) uint8_t type;
@property(readonly) BOOL isFixed;
@property(readonly) NSStringEncoding stringEncoding;
@property(readonly) NSString *typeName;
@property(readonly) int displaySize;
@property (readonly) uint8_t digitsTotal, digitsFraction;
@property (readonly) M2ObjectReader *objectReader;

@property (readonly) BOOL isNumeric;

-(BOOL)parseBytes:(const uint8_t*)columnBytes version:(uint8_t)jetVersion error:(NSError**)outError;
-(void)setArg1:(uint32_t)arg1 arg2:(uint32_t)arg2;

@end
