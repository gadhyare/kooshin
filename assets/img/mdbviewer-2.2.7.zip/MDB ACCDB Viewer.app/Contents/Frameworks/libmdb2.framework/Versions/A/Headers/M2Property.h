//
//  M2Property.h
//  libmdb2
//
//  Created by Jakob Egger on 06.09.12.
//
//

#import <Foundation/Foundation.h>

@interface M2Property : NSObject<NSCopying> {
	NSMutableDictionary *columnProperties;
	NSDictionary *tableProperties;
}
@property(readonly) NSMutableDictionary *columnProperties;
@property(readonly) NSDictionary *tableProperties;



- (id)initWithData:(NSData*)someData encoding:(NSStringEncoding)stringEncoding database:(M2Database*)db error:(NSError**)outError;

@end
