//
//  M2ObjectReader.h
//  libmdb2
//
//  Created by Jakob Egger on 06.09.12.
//
//

#import <Foundation/Foundation.h>

@class M2Column, M2Database;

@interface M2ObjectReader : NSObject {
	uint8_t columnType;
	uint16_t columnFlags;
	NSString *columnName;
	uint8_t columnDigitsFraction;
	NSStringEncoding columnStringEncoding;
	
	M2Database *database;
}

-(id)initWithColumn:(M2Column*)col;
-(id)initWithType:(uint8_t)type encoding:(NSStringEncoding)enc database:(M2Database*)db;

-(id)objectForBytes:(const void*)dataStart length:(NSUInteger)length error:(NSError**)outError;

/**
 * Returns an NSNumber from an Integer of a given length.
 * Single byte (chars) are unsigned, all others are signed.
 */
-(NSNumber*)numberForIntegerBytes:(const void*)bytes length:(size_t)length;

/**
 * Returns a string with a given encoding.
 */
-(NSString*)stringWithUnicodeCompressedBytes:(const char*)bytes length:(size_t)length;

/**
 * Reads data from an OLE or MEMO field
 */
-(NSData*)readLongBytes:(const uint8_t*)bytes length:(size_t)length error:(NSError**)outError;

-(NSDecimalNumber*)decimalNumberWithBytes:(const void*)bytes length:(size_t)length;
-(NSNumber*)numberWithFloatFromBytes:(const void*)bytes length:(size_t)length;
-(NSDate*)dateFromBytes:(const void*)bytes length:(size_t)length;


@end
