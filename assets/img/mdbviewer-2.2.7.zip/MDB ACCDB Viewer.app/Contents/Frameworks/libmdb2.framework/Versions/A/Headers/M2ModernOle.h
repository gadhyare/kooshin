//
//  M2ModernOle.h
//  libmdb2
//
//  Created by Jakob Egger on 12.02.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface M2ModernOle : NSObject<NSCopying> {
	NSData *containedData;
	NSString *filename;
}

@property(readonly) NSData *containedData;
@property(readonly) NSString *filename;

- (id)initWithData:(NSData*)someData encoding:(NSStringEncoding)stringEncoding;
@end
