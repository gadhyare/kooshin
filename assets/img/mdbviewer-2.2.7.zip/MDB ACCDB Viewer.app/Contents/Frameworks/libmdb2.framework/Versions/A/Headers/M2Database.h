//
//  libmdb2.h
//  libmdb2
//
//  Created by Jakob Egger on 22.01.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
	M2ObjectTypeForm = 0,
	M2ObjectTypeTable = 1,
	M2ObjectTypeMacro = 2,
	M2ObjectTypeSystemTable = 3,
	M2ObjectTypeReport = 4,
	M2ObjectTypeQuery = 5,
	M2ObjectTypeLinkedTable = 6,
	M2ObjectTypeModule = 7,
	M2ObjectTypeRelationship = 8,
	
	M2ObjectTypeDatabaseProperty = 11
} M2ObjectTypes;

@class M2Table;

@interface M2Database : NSObject {
	
	/* Basic variables needed for accessing the file */
	NSURL *url;
	NSData *data;
	const uint8_t *bytes;
	size_t fileSize;
	
	/* data from the file header */
	NSUInteger fullJetVersion;
	uint8_t jetVersion;
	uint16_t codepage, collation;
	NSDate *creationDate;
	NSStringEncoding stringEncoding, systemStringEncoding;
	uint32_t dbkey;
	size_t pageSize;
	NSString *password;
	
	/* Objects in the database */
	NSArray *userTableNames, *systemTableNames;
	NSDictionary *pagesForTableName, *metadataForTablePage, *namesForTablePage;
}
@property(readonly) NSURL *url;
@property(readonly) uint8_t jetVersion;
@property(readonly) uint16_t codepage, collation;
@property(readonly) NSDate *creationDate;
@property(readonly) size_t pageSize, fileSize;
@property(readonly) NSStringEncoding stringEncoding, systemStringEncoding;
@property(readonly) BOOL isEncrypted;


- (id)initWithURL:(NSURL*)dbUrl;

-(BOOL)openWithError:(NSError**)outError;
-(void)close;

-(BOOL)readHeaderWithError:(NSError**)outError;
-(NSData*)pageAtIndex:(NSUInteger)index error:(NSError**)outError;
-(NSData*)dataForRecordId:(uint32_t)recordId flags:(uint16_t*)outFlags error:(NSError**)outError;

-(NSArray*)userTableNamesError:(NSError**)outError;
-(NSArray*)systemTableNamesError:(NSError**)outError;
-(M2Table*)tableByName:(NSString*)tableName error:(NSError**)outError;
-(M2Table*)tableByPage:(uint32_t)page error:(NSError**)outError;
-(NSString*)tableNameForPage:(uint32_t)page error:(NSError**)outError;

@end
