//
//  M2Index.h
//  libmdb2
//
//  Created by Jakob Egger on 22.12.12.
//
//

#import <Foundation/Foundation.h>

typedef enum {
	M2IndexTypeNormal = 0,
	M2IndexTypePrimaryKey = 1,
	M2IndexTypeUnrealIndex = 2
} M2IndexType;

@class M2Table;

@interface M2Index : NSObject {
	/* manual properties */
	M2Table *_table;
	
	/* ivars for synthesized properties */
	NSString* name;
	uint32_t unknownA1;
	uint32_t unknownA2;
	uint32_t rowCount;
	uint32_t unknownB1;
	NSArray *columns;
	uint32_t unknownB2;
	uint32_t firstPage;
	uint16_t flags;
	uint32_t unknownB3;
	uint32_t unknownB4;
	
	uint32_t unknownC1;
	uint32_t indexNumber;
	uint32_t indexColumnNumber;
	uint32_t unknownC2;
	uint32_t unknownC3;
	M2IndexType type;
	uint32_t unknownC4;
	uint32_t unknownC5;
	uint32_t unknownC6;
}


@property(readonly) M2Table* table;
@property(copy) NSString* name;
@property uint32_t unknownA1;
@property uint32_t unknownA2;
@property uint32_t rowCount;
@property uint32_t unknownB1;
@property(copy) NSArray *columns;
@property uint32_t unknownB2;
@property uint32_t firstPage;
@property uint16_t flags;
@property uint32_t unknownB3;
@property uint32_t unknownB4;

@property uint32_t unknownC1;
@property uint32_t indexNumber;
@property uint32_t indexColumnNumber;
@property uint32_t unknownC2;
@property uint32_t unknownC3;
@property M2IndexType type;
@property uint32_t unknownC4;
@property uint32_t unknownC5;
@property uint32_t unknownC6;

@property(readonly) NSDictionary *dictionaryRepresentation;

-(id)initWithTable:(M2Table*)table;


@end
