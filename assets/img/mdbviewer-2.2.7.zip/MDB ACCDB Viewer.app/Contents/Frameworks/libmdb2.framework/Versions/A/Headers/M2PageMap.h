//
//  M2PageMap.h
//  libmdb2
//
//  Created by Jakob Egger on 26.01.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#define M2PageMapNoIndex 0xFFFFFFFF

@class M2Database;

@interface M2PageMap : NSObject {
	NSData *masterMap;
	M2Database *mdb;
	size_t pageSize;
	size_t bitmapSize;
	size_t fileSize;
	NSData *mapPages[33];
	uint32_t recordId;
}

-(id)initWithDatabase:(M2Database*)someDb pageRowPointer:(uint32_t)pgRowPointer;
-(size_t)usedPageIndexOnOrAfter:(size_t)startPageIndex error:(NSError**)outError;

@end
