//
//  M2Ole.h
//  Migrationist
//
//  Created by Jakob und Klara on 13.05.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface M2Ole : NSObject<NSCopying> {
	NSData *containedData;
    
	// Package header
	NSUInteger objectType;
	NSString *friendlyName, *className;
	
	// OLE header
	NSUInteger oleVersion, oleFormat;
	NSString *oleObjectTypeName;
	NSUInteger oleFileSize;
	
	// Package stream header
	NSUInteger psFilenameLength, psPath1Length, psPath2Length;
	NSUInteger psSignature, psWeirdFlags;
	NSString *psFilename, *psPath1, *psPath2;
	NSUInteger psPayloadSize;
}
@property(readonly) NSData *containedData;
@property(readonly) NSString *filename;

- (id)initWithData:(NSData*)someData encoding:(NSStringEncoding)stringEncoding error:(NSError**)outError;

@end
