//
//  xlsx_stream_writer.h
//  xlsx-stream-writer
//
//  Created by Jakob Egger on 29.04.13.
//  Copyright (c) 2013 Egger Apps e. U. All rights reserved.
//

#include <time.h>

typedef struct xlsx_file* xlsx_file_ref;

xlsx_file_ref xlsx_open_file( const char *path, char **errorString );
int xlsx_new_sheet( xlsx_file_ref file, const char *sheet_name, char **errorString );
int xlsx_write_bool( xlsx_file_ref file, int row, int column, char value, char **errorString );
int xlsx_write_int( xlsx_file_ref file, int row, int column, long long value, char **errorString );
int xlsx_write_double( xlsx_file_ref file, int row, int column, double value, char **errorString );
int xlsx_write_date( xlsx_file_ref file, int row, int column, struct tm value, char **errorString );
int xlsx_write_unix_time( xlsx_file_ref file, int row, int column, time_t unixTime, char **errorString );
int xlsx_write_string( xlsx_file_ref file, int row, int column, const char *value, char **errorString );
int xlsx_close(xlsx_file_ref file, char **errorString);